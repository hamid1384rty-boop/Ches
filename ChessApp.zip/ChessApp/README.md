# شطرنج (اپ اندروید، کاملاً آفلاین)

نسخه‌ی اندرویدی `chess_web.py`. به‌جای سرور Flask، موتور شطرنج به جاوااسکریپت منتقل شده و داخل یک WebView اجرا می‌شود؛ پس نیاز به اینترنت، پایتون یا Stockfish ندارد.

## ساخت APK

### روش ۱: Android Studio
1. پوشه‌ی پروژه را با Android Studio باز کنید و صبر کنید Gradle sync تمام شود.
2. منوی `Build > Build Bundle(s) / APK(s) > Build APK(s)`
3. خروجی: `app/build/outputs/apk/debug/app-debug.apk`

### روش ۲: GitHub Actions (بدون نصب چیزی)
1. محتویات همین پوشه را در یک ریپوی GitHub آپلود کنید (پوشه‌ی `.github` هم باید باشد).
2. تب Actions ← `Build APK` ← Run workflow (یا با هر push خودکار اجرا می‌شود).
3. بعد از پایان، فایل `chess-apk` را از بخش Artifacts دانلود کنید و `app-debug.apk` را نصب کنید.

## ساختار
- `app/src/main/assets/index.html` : رابط کاربری + موتور شطرنج (همه‌چیز در یک فایل)
- `app/src/main/java/.../MainActivity.kt` : WebView
- سطح ۱ تا ۱۰ مثل نسخه‌ی اصلی؛ بازی خودکار ذخیره می‌شود و با بازکردن مجدد اپ ادامه پیدا می‌کند.
